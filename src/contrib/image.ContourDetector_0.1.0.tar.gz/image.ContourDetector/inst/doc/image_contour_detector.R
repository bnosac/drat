## ------------------------------------------------------------------------
library(image.ContourDetector)
library(pixmap)
imagelocation <- system.file("extdata", "image.pgm", package="image.ContourDetector")
image <- read.pnm(file = imagelocation, cellres = 1)
x <- image@grey * 255
contourlines <- image_contour_detector(x)
contourlines
par(mai = c(0, 0, 0, 0), mar = c(0, 0, 0, 0))
plot(image)
plot(contourlines, add = TRUE, col = "red")

## ------------------------------------------------------------------------
library(magick)
f <- tempfile(fileext = ".pgm")
x <- image_read(system.file("extdata", "atomium.jpg", package="image.ContourDetector"))
x <- image_convert(x, format = "pgm", depth = 8)
image_write(x, path = f, format = "pgm")

image <- read.pnm(file = f, cellres = 1)
contourlines <- image_contour_detector(image@grey * 255)
contourlines
par(mfrow = c(1, 2), mai = c(0, 0, 0, 0), mar = c(0, 0, 0, 0))
plot(image)
plot(contourlines, add = TRUE, col = "red", lwd = 2)
plot(contourlines)

