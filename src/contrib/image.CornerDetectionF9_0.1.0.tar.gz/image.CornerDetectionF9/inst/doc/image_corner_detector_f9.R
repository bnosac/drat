## -----------------------------------------------------------------------------
library(pixmap)
library(image.CornerDetectionF9)
imagelocation <- system.file("extdata", "chairs.pgm", package="image.CornerDetectionF9")
image <- read.pnm(file = imagelocation, cellres = 1)
x <- image@grey * 255
corners <- image_detect_corners(x, 100)
plot(image)
points(corners$x, corners$y, col = "red", pch = 20, lwd = 0.5)

