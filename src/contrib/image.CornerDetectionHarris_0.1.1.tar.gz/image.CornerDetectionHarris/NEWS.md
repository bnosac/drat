## CHANGES IN VERSION 0.1.1

- Fix unconditional use of omp.h
- Fix address sanitizer issue in gaussian.cpp 

## CHANGES IN VERSION 0.1.0

- Initial release based on https://github.com/jsanchezperez/harris_corner_detector commit 4008f032667b2bb0d4b5f48d903a518f595afd5f