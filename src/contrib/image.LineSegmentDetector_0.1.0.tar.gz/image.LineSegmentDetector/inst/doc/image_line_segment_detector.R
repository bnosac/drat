## ------------------------------------------------------------------------
library(image.LineSegmentDetector)
library(pixmap)
image <- read.pnm(file = system.file("extdata", "le-piree.pgm", package="image.LineSegmentDetector"), cellres = 1)
linesegments <- image_line_segment_detector(image@grey * 255)
plot(image)
plot(linesegments, add = TRUE, col = "red")

## ------------------------------------------------------------------------
library(magick)
f <- tempfile(fileext = ".pgm")
x <- image_read(system.file("extdata", "atomium.jpg", package="image.LineSegmentDetector"))
x
x <- image_convert(x, format = "pgm", depth = 8)
image_write(x, path = f, format = "pgm")

image <- read.pnm(file = f, cellres = 1)
linesegments <- image_line_segment_detector(image@grey * 255)
par(mfrow = c(1, 2), mai = c(0, 0, 0, 0), mar = c(0, 0, 0, 0))
plot(image)
plot(linesegments)
par(mfrow = c(1, 2), mai = c(0, 0, 0, 0), mar = c(0, 0, 0, 0))
plot(image)
plot(linesegments, add = TRUE, col = "red", lwd = 2)
plot(linesegments)

