// Copyright (C) 2006  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_BASe64_
#define DLIB_BASe64_

#include "base64/base64_kernel_1.h"

#endif // DLIB_BASe64_

